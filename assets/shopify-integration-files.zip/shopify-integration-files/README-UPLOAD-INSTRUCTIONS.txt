ADORNME SHOPIFY INTEGRATION — UPLOAD INSTRUCTIONS
==================================================

Two files to upload to your GitHub repo:

1. assets/shopify-checkout.js  (NEW FILE — add to assets/ folder)
2. product.html  (UPDATED FILE — replaces existing product.html)

To upload to GitHub:
--------------------
Go to: https://github.com/Adornmejewelry/adornme-site

1. Click "assets" folder
2. Click "Add file" → "Upload files"
3. Drag shopify-checkout.js into the upload area
4. Scroll down, commit message: "Add Shopify checkout integration"
5. Click "Commit changes"

6. Go back to main repo page
7. Click on the existing "product.html"
8. Click the pencil/edit icon (top right of the file view)
9. Open this product.html in a text editor, copy ALL contents
10. Replace the entire file contents in GitHub with the new version
11. Scroll down, commit message: "Wire Add to bag to Shopify"
12. Click "Commit changes"

Vercel will auto-deploy in 30-60 seconds.
